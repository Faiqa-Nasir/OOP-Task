#include "Header.h"
#include<iostream>
using namespace std;
int main()
{

	//display ,length function and parameter constructor test 

	char array[] = "1234";
	MyString one(array);
	one.display();
	cout << one.getLength() << endl;


	//copy creation and assignment and << >> operator working
	MyString two(one);
	two.display();
	char array2[] = "oop task";
	MyString three(array2);
	cout << three.getLength() << endl;
	three.display();
	three = one;
	cout << three;
	cin >> three;
	cout << endl;
	cout << three;

	//concatenation

	MyString four = three+one;
	cout << four;

	//equal or less

	if (four == three)
		cout << "equal\n";
	else
		cout << "not equal\n";
	char arr[] = "00444";
	MyString five(arr);

	if (five <= four)
		cout << "greater or equal\n";
	if (five < four)
		cout << "five is less than four\n";

	//+=
	five += five;
	cout << five << endl;

	//set str 
	four.setStr(arr);
	four.display();

	//to int
	int f=five.operator int();
	cout << f + 1 << endl;

	//to char*
	char* array4;
	array4 = five.operator char* ();
	cout << array4[0] << endl;

	//++
	++four;
	cout << four;

	//substr
	MyString six = four.subString(0, 4);
	six.display();


	//find 1st occ
	cout << six.find('5') << endl;

	//find substr first occ 
	char a[] = "programminginging";
	char b[] = "ing";
	MyString seven(a);
	MyString eight(b);
	cout << seven.find(eight) << endl;
	//after certain index

	cout << seven.find(eight, 10) << endl;

	//last occ of char
	cout << seven.rfind('m') << endl;

	//last occ of substr
	cout << seven.rfind(eight) << endl;
	//+
	seven = eight + seven;
	cout << seven;

	
	cout << "*******";
}