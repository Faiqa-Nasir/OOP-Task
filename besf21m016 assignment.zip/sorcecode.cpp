#include "Header.h"
#include<iostream>
#include<conio.h>
using namespace std;

//default constructor

MyString::MyString()
{
	length = 0;
	str = new char[length];
	for (int i = 0; i < length; i++)
		str[i] = ' ';
}

//parameterized constructor

MyString::MyString(const char* array)
{
	int l = 0;
	for (int i = 0; array[i] != '\0'; i++)
	{
		l++;
	}
	str = new char[l + 1];

	for (int i = 0; i < l; i++)
	{
		str[i] = array[i];
	}
	str[l] = '\0';
	length = l;
}

//destructor

MyString::~MyString()
{
	if (str)
	{
		delete[] str;
		str = nullptr;
	}
}

//display string

void MyString::display() const
{
	for (int i = 0; i < length; i++)
		cout << str[i];
	cout << endl;
}

//returns length of the string

int MyString::getLength() const
{
	return length;
}

//copy constructor

MyString::MyString(const MyString& copy)
{
	this->length = copy.length;
	this->str = new char[(copy.length) + 1];
	for (int i = 0; i < copy.length; i++)
	{
		this->str[i] = copy.str[i];
		if (i + 1 == copy.length)
			str[i + 1] = '\0';
	}
}

//overloading assignment operator

const MyString& MyString::operator=(const MyString& copy)
{
	if (this->str != copy.str)
	{
		this->length = copy.length;
		delete[] this->str;
		this->str = new char[(copy.length) + 1];
		for (int i = 0; i < copy.length; i++)
		{
			this->str[i] = copy.str[i];

			if (i + 1 == copy.length)
				this->str[i + 1] = '\0';
		}
		return *this;
	}
	else
	{
		return *this;
	}
}

//overloading stream insertion operator as friend function

ostream& operator<<(ostream& obj, const MyString& m)
{
	for (int i = 0; i < m.length; i++)
		obj << m.str[i];
	cout << endl;
	return obj;
}

//overloading stream extraction operator as friend function 

istream& operator>>(istream& obj, MyString& m)
{
	cout << "input length : ";
	obj >> m.length;
	cout << endl;
	cout << "input string : ";
	if (m.str)
	{
		delete[] m.str;
		m.str = new char[m.length + 1];
	}
	for (int i = 0; i < m.length; i++)
		cin>>m.str[i];
	m.str[m.length] = '\0';
	cout << endl << "string saved" << endl;
	return obj;
}

//overloading + operator. you can perform concatenation using +operator

MyString MyString::operator+(const MyString& m) const
{

	MyString newstr;
	newstr.length = this->length + m.length;
	newstr.str = new char[this->length + m.length + 1];
	for (int i = 0; i < this->length; i++)
	{
		newstr.str[i] = this->str[i];
	}
	int d = 0;
	for (int i = this->length; i < newstr.length; i++)
	{
		newstr.str[i] = m.str[d];
		d++;
	}
	newstr.str[newstr.length] = '\0';
	return newstr;
}

//overloading == operator

bool MyString::operator==(const MyString& m) const
{
	if (this->length == m.length)
	{
		bool flag = true;
		for (int i = 0; i < this->length; i++)
		{
			if (this->str[i] != m.str[i])
			{
				return false;
			}
		}
		if (flag == true)
			return true;
	}
	else
		return false;
}

//overloading < operator

bool MyString::operator<(const MyString& m) const
{

	for (int i = 0; i < this->length; i++)
	{
		if (this->str[i] != m.str[i])
		{
			if (this->str[i] < m.str[i])
				return true;
			else
				return false;
		}

	}
	return false;
}

//overloading <= operator

bool MyString::operator<=(const MyString& m) const
{
	if (m == (*this) || (*this) < m)
		return true;
	else
		return false;
}

//overloading += operator

MyString MyString::operator += (const MyString& m)
{
	*this = (*this) + m;
	return *this;
}

//set data member of instance

void MyString::setStr(const char* array)
{
	int l = 0;
	for (int i = 0; array[i] != '\0'; i++)
	{
		l++;
	}
	str = new char[l + 1];

	for (int i = 0; i < l; i++)
	{
		str[i] = array[i];
	}
	str[l] = '\0';
	length = l;

}

//for conversion from 'MyString' to 'int' 

MyString::operator int()
{
	for (int i = 0; i < length; i++)
	{
		if (str[i] < 48 && str[i]>57)
			return -1;
	}
	int k = str[0] - 48;
	for (int i = 0; i < length; i++)
	{
		k = (k * 10) + (str[i] - 48);
	}
	return k;
}

//for conversion from 'MyString' to 'char*' (C-style string) 

MyString::operator char* ()
{
	char* array = new char[(this->length) + 1];
	for (int i = 0; i < this->length; i++)
	{
		array[i] = this->str[i];
	}
	return array;
}

//overloading pre-increment operator 

MyString& MyString::operator++()
{

	for (int i = 0; i < this->length; i++)
	{
		this->str[i] = (this->str[i]) + 1;
	}
	return *this;
}

//returns substring of the string from index 'start' to 'end' 

MyString MyString::subString(int m, int n) const
{
	MyString temp;
	temp.length = n;
	temp.str = new char[n + 1];
	int o = 0;
	for (int i = m; i < m + n; i++)
	{
		temp.str[o] = this->str[i];
		o++;
	}
	temp.str[n] = '\0';

	return temp;
}

//returns index of first occurence of substring in the string 

int MyString::find(const MyString& m) const
{
	bool flag = true;
	int k = 0;
	for (int i = 0; i < this->length; i++)
	{

		if (m.str[0] == this->str[i])
		{

			flag = true;
			for (int j = i; j < i + (m.length); j++)
			{
				if (this->str[j] == m.str[k])
				{
					k++;
				}
				else
				{
					flag = false;
					break;
				}
			}
		}
		if (flag == true && k == m.length)
			return i;
		else
		{
			flag = true;
			k = 0;
		}
	}

	return -1;
}

//returns index of first occurence of char in the string 

int MyString::find(const char ch) const
{
	for (int i = 0; i < this->length; i++)
	{
		if (this->str[i] == ch)
			return i;
	}
	return -1;
}

//returns index of first occurence of substring in the string after index 'start'

int MyString::find(const MyString& m, int start) const
{

	bool flag = true;
	int k = 0;
	for (int i = start + 1; i < this->length; i++)
	{

		if (m.str[0] == this->str[i])
		{
			flag = true;

			for (int j = i; j < i + (m.length); j++)
			{
				if (this->str[j] == m.str[k])
				{
					k++;
				}
				else
				{
					flag = false;
					break;
				}
			}
		}
		if (flag == true && k == m.length)
			return i;
		else
		{
			flag = true;
			k = 0;
		}
	}

	return -1;
}

//returns index of last occurence of substring in the string 

int MyString::rfind(const MyString& m) const
{
	bool flag = true;
	int ans = -1;
	int k = 0;
	for (int i = 0; i < this->length; i++)
	{
		k = 0;

		if (m.str[0] == this->str[i])
		{

			for (int j = i; j < i + (m.length); j++)
			{
				if (this->str[j] == m.str[k])
				{

					k++;
				}
				else
				{
					flag = false;
					break;
				}
			}
		}
		if (flag == true && k == m.length)
		{
			ans = i;

		}
		else
		{
			flag = true;
		}
	}

	return ans;
}

//returns index of last occurence of char in the string

int MyString::rfind(const char ch) const
{
	int l = -1;
	for (int i = 0; i < this->length; i++)
	{
		if (this->str[i] == ch)
			l = i;
	}
	return l;
}